q = [90 -90] * pi/180
qd = [2 -3]
qdd = [3 4] 

[idyn_rtb(q, qd, qdd); idyn_roy(q, qd, qdd)]