assume that spatial math is in your path

ID.m            inverse dynamics using spatial vector notation
test_roy.m      test script for ID.m

compare.m       compare results of RTB RNE and spatial vector for planar 2 link, uses:
  idyn_roy.m      ID for spatial vector
  idyn_rtb.m      ID for RNE
